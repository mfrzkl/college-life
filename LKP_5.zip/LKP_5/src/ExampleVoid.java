public class ExampleVoid {
    public static void main(String[] args){
        merhodRankPoints(255.7);
    }

    private static void merhodRankPoints(double points) {
        
    }
}
