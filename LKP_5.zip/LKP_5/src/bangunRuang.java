import java.util.Scanner;

public class bangunRuang {

    private static int sisi;
    Scanner scan = new Scanner(System.in);

    public static void main (String[] args){
        int lp = luasPersegi(sisi);
        System.out.println("Luas Persegi: "+lp);
    }

    public static int luasPersegi(int sisi){
        sisi = scan.nextInt();
        luasP = sisi * sisi;
        return luasP;

    }

    public static int luasKubus(int sisi){
        sisi = scan.nextInt;
        luasK = 6 * (sisi * sisi);
        return luasK;
    }

}
