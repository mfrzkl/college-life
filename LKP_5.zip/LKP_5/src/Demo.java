public class Demo {
    public static void main(String[] args){
        // using the max() method of Math class
        System.out.println("The Maximum number is: " +
                Math.max(9,7));
    }
    // maka akan mengeluarkan out: The maximum number is: 9
}
